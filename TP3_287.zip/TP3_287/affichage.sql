 -- Permet d'afficher le contenue de chacune des tables
SELECT * FROM Membre;
SELECT * FROM Lot;
SELECT * FROM LotMembre;
SELECT * FROM DemandeMembreLot;
SELECT * FROM Plante;
SELECT * FROM Culture;
