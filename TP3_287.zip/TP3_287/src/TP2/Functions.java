package TP2;

import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Functions {

	private Connection co;
	
	// Tables
	public Cultures Culture;
	public DemandeMembreLots DemandeMembreLot;
	public Lots Lot;
	public Membres Membre;
	public LotMembres LotMembre;
	public Plantes Plante;
	
	public Functions(Connection connect) throws SQLException {
		this.co = connect;
		this.Culture = new Cultures(connect);
		this.DemandeMembreLot = new DemandeMembreLots(connect);
		this.Lot = new Lots(connect);
		this.Membre = new Membres(connect);
		this.LotMembre = new LotMembres(connect);
		this.Plante = new Plantes(connect);
	}
	
	public void showAll() throws SQLException {
		Culture.showTable();
		DemandeMembreLot.showTable();
		Lot.showTable();
		Membre.showTable();
		LotMembre.showTable();
		Plante.showTable();
	}
	
	// R01
	public int inscrireMembre(String nom, String prenom, String noMembre, String motDePasse) throws SQLException {
		int state = Membre.inscrireMembre(nom, prenom, motDePasse, noMembre);
		System.out.println("\nR01 - �tat Inscrire Membre : " + state + "\n");
		return state;
	}
	
	
	// R02
	public int supprimerMembre(String noMembre) throws SQLException {
		int state = Membre.supprimerMembre(noMembre);
		System.out.println("\nR02 - �tat Supprimer Membre : " + state + "\n");
		return state;
	}
	
	// R03
	public int promouvoirAdministrateur(String noMembre) throws SQLException {
		int state = Membre.promouvoirAdministrateur(noMembre);
		System.out.println("\nR03 - �tat Promouvoir Administrateur : " + state + "\n");
		return state;
	}
	
	// R04
	public int ajouterLot(String nomLot, int nbMaxMembre) throws SQLException {
		int state = Lot.ajouterLot(nomLot, nbMaxMembre);
		System.out.println("\nR04 - �tat Ajouter Lot : " + state + "\n");
		return state;
	}
	
	// R05
	public int supprimerLot(String nomLot) throws SQLException {
		int state = 0; // 0 car on y ajoute les erreurs soudjacentes
		state += Lot.supprimerLot(nomLot);
		state += LotMembre.supprimerLot(nomLot);
		state += DemandeMembreLot.supprimerLot(nomLot);
		System.out.println("\nR05 - �tat Supprimer Lot : " + state + "\n");
		return state;
	}
	
	// R06
	public int rejoindreLot(String nomLot, String noMembre) throws SQLException {
		int state = DemandeMembreLot.rejoindreLot(nomLot, noMembre);
		System.out.println("\nR06 - �tat Rejoindre Lot : " + state + "\n");
		return state;
	}
	
	// R07
	public int accepterDemande(String nomLot, String noMembre) throws SQLException {
		int state = 0;
		state += LotMembre.ajouterTuple(nomLot, noMembre);
		state += DemandeMembreLot.supprimerDemande(nomLot, noMembre);
		System.out.println("\nR07 - �tat Accepter Demande : " + state + "\n");
		return state;
	}
	
	// R08
	public int refuserDemande(String nomLot, String noMembre) throws SQLException {
		int state = DemandeMembreLot.supprimerDemande(nomLot, noMembre);
		System.out.println("\nR08 - �tat Refuser Demande : " + state + "\n");
		return state;
	}
	
	// R09
	public int ajouterPlante(String nomPlante, int tempsCulture) throws SQLException {
		int state = Plante.ajouterPlante(nomPlante, tempsCulture);
		System.out.println("\nR09 - �tat Ajouter Plante : " + state + "\n");
		return state;
	}
	
	// R10
	public int retirerPlante(String nomPlante) throws SQLException {
		int state = Plante.retirerPlante(nomPlante);
		System.out.println("\nR10 - �tat Retirer Plante : " + state + "\n");
		return state;
	}
	
	// R11
	public int planterPlante(String nomPlante, String nomLot, String noMembre, int nbExemplaires, Date datePlantation) throws SQLException {
			int state = Culture.planterPlante(nomPlante, nomLot, noMembre, nbExemplaires, datePlantation);
			System.out.println("\nR11 - �tat Planter Plante : " + state + "\n");
			return state;
	}
	
	//R12
	public int recolterPlante(String nomPlante, String nomLot, Date dateRecolte) throws SQLException {
		int state = Culture.recolterPlante(nomPlante, nomLot, dateRecolte);
		System.out.println("\nR12 - �tat Recolter Plante : " + state + "\n");
		return state;
	}

	//R16
	public void afficherPlantesLot(String nomLot) throws SQLException {
		Culture.afficherPlantesLot(nomLot);
	}
	
}
