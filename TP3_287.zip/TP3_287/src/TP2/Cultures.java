package TP2;

import java.sql.*;
import java.util.Calendar;


public class Cultures extends Table {

	public Cultures(Connection beepboop) throws SQLException {
		super(beepboop);
	}

	public void showTable() throws SQLException
    {
        Statement s = con.createStatement();
        String query = "SELECT * FROM Culture";
        ResultSet rSet = s.executeQuery(query);
        System.out.println("\nCulture :\n| nomPlante | nomLot | noMembre | nbExemplaires | datePlantation | dateRecolte |\n"
        				  +"=================================================================");
        while (rSet.next()) {
            String nomPlante = rSet.getString("nomPlante");
            String nomLot = rSet.getString("nomLot");
            String noMembre = rSet.getString("noMembre");
            String nbExemplaires = rSet.getString("nbExemplaires");
            String datePlantation = rSet.getString("datePlantation");
            Date dateRecolte = rSet.getDate("dateRecolte");
            
            System.out.println("| "+nomPlante+" | "+nomLot+" | "+noMembre+" | "+nbExemplaires+" | "+datePlantation.toString()+" | "+dateRecolte.toString()+" |");
        }
        System.out.println("");
    }
	
	public int planterPlante(String nomPlante, String nomLot, String noMembre, int nbExemplaires, Date datePlantation) throws SQLException {
		int state = 1;
		
		String q2 = "SELECT tempsCulture FROM Plante WHERE nomPlante = '"+nomPlante+"';";
		Statement s = con.createStatement();
		ResultSet rs = s.executeQuery(q2);
		rs.next();
		int tempsCulture = rs.getInt("tempsCulture") ;
		
		Calendar c = Calendar.getInstance();
		c.setTime(datePlantation);
		c.add(Calendar.DATE,  tempsCulture);
		Date dateRecolte = new Date(c.getTimeInMillis());
		
		String query = "INSERT INTO Culture(nomPlante, nomLot, noMembre, nbExemplaires, datePlantation, dateRecolte) VALUES (?, ?, ?, ?, ?, ?);";
		PreparedStatement PS = con.prepareStatement(query);
		PS.setString(1, nomPlante);
		PS.setString(2, nomLot);
		PS.setString(3, noMembre);
		PS.setInt(4, nbExemplaires);
		PS.setDate(5, datePlantation);
		PS.setDate(6, dateRecolte);
		
		int affectedRows = 0;
		
		try {
			affectedRows = PS.executeUpdate();
			con.commit();
			PS.close();
			
		}
		catch (Exception e) {
			System.out.println(e);
			state = 1;
		}
		
		if (affectedRows != 1) {
			state = 0;
		}
		return state;
	}
	
	
	// R12
	public int recolterPlante(String nomPlante, String nomLot, Date date) throws SQLException {
		int state = 1;
		
		String q2 = "DELETE * FROM Culture WHERE dateRecolte = ? AND nomLot = ? AND nomPlante = ?;";
		
		PreparedStatement PS = con.prepareStatement(q2);
		PS.setDate(1, date);
		PS.setString(2, nomLot);
		PS.setString(3, nomPlante);
		
		PS.executeUpdate();
		state = 0;
		con.commit();
		PS.close();
		

		
		return state ;
	}
	
	// R16
	public void afficherPlantesLot (String nomLot) throws SQLException {		
		String query = "SELECT Culture.nomPlante, datePlantation, dateRecolte" + 
				"  FROM Culture" +
				"  WHERE Culture.nomLot = '"+nomLot+"';";
		Statement s = con.createStatement();
		ResultSet rSet = s.executeQuery(query);
        System.out.println("\nCulture :\n| nomPlante | datePlantation | dateRecolte\n"
        				  +"=================================================================");
        while (rSet.next()) {
            String nomPlante = rSet.getString("nomPlante");
            Date datePlantation = rSet.getDate("datePlantation");
    		Date dateRecolte = rSet.getDate("dateRecolte");
            System.out.println("| "+nomPlante+" | "+datePlantation.toString()+" | "+dateRecolte.toString()+" |");
        }
        System.out.println("");
	}
}
