package TP2;

import javax.persistence.*;

public class LotMembre
{
    @Id
    @GeneratedValue
    private long m_id;
    
    private String m_nomLot;
    private String m_noMembre;
    

        
    public LotMembre() {    
    }
    
    public LotMembre(String nomLot, String noMembre) {    
        m_nomLot = nomLot;
        m_noMembre = noMembre;
    }
    
    public String getNomLot() {
        return m_nomLot;
    }
    
    public String getNoMembre() {
        return m_noMembre;
    }
}
