package TP2;

import javax.persistence.*;


public class Lot
{
    @Id
    @GeneratedValue
    private long m_id;
    
    private String m_nomLot;
    private int m_nbMaxMembre;

    @ManyToMany
    private Membre m_membre;
    @ManyToMany
    private Culture m_culture;
    
    public Lot() {}
    
    public Lot(String nomLot, int nbMaxMembre) {
        m_nomLot = nomLot;
        m_nbMaxMembre = nbMaxMembre;
        m_membre = null;
        m_culture = null;
    }
    
    public String getNomLot() {
        return m_nomLot;
    }
    
    public int getNbMaxMembre() {
        return m_nbMaxMembre;
    }
    
    
    public Membre getMembre() {
        return m_membre;
    }
    
    public Culture getCulture() {
        return m_culture;
    }

    public void retourner() {
        m_membre = null;
        m_culture = null;
    }
    
}
