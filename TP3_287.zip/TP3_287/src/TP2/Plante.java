package TP2;

import javax.persistence.*;

public class Plante
{
    @Id
    @GeneratedValue
    private long m_id;
    
    private String m_nomPlante;
    private int m_tempsCulture;
    private boolean m_estDisponible;
    
    @OneToMany(mappedBy = "m_plante")
    private Cultures m_culture;
    
    public Plante() {}
    
    public Plante(String nomPlante, int tempsCulture, boolean estDisponible) {    
        m_nomPlante = nomPlante;
        m_tempsCulture = tempsCulture;
        m_estDisponible = estDisponible;
    }
    
    public String getNomPlante() {
        return m_nomPlante;
    }
    
    public int getTempsCulture() {
        return m_tempsCulture;
    }

    public boolean getEstDisponible() {
        return m_estDisponible;
    }
    
    

}
