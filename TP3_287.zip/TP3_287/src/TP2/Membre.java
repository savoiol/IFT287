package TP2;

import javax.persistence.*;

public class Membre
{
    @Id
    @GeneratedValue
    private long m_id;
    
    private String m_nom;
    private String m_prenom;
    private String m_noMembre;
    private String m_motDePasse;
    
    @ManyToMany
    private Lot m_lot;
    @ManyToMany
    private Culture m_culture;
    
    public Membre() {    
    }
    
    public Membre(String nom, String prenom, String noMembre, String motDePasse) {    
        m_nom = nom;
        m_prenom = prenom;
        m_noMembre = noMembre;
        m_motDePasse = motDePasse;
        m_lot = null;
        m_culture = null;
    }
    
    public String getNom() {
        return m_nom;
    }
    
    public String getPrenom() {
        return m_prenom;
    }

    public String getNoMembre() {
        return m_noMembre;
    }

    public String getMotDePasse() {
        return m_motDePasse;
    }
    
    public Lot getLot() {
        return m_lot;
    }
    
    public Culture getCulture() {
        return m_culture;
    }

    public void retourner() {
        m_lot = null;
        m_culture = null;
    }
    
}
