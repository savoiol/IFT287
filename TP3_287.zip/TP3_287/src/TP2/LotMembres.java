package TP2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class LotMembres extends Table {

	public LotMembres(Connection beepboop) throws SQLException {
		super(beepboop);
	}
	
	public int ajouterTuple(String nomLot, String noMembre) throws SQLException {
		int state = 1;
    	int affectedRows = 0;
    	PreparedStatement ps = con.prepareStatement("INSERT INTO LotMembre(nomLot, noMembre) VALUES (?,?)");
    	ps.setString(1, nomLot);
    	ps.setString(2, noMembre);
    	
    	this.supprimerTuple(nomLot, noMembre);
    	try {
    	affectedRows = ps.executeUpdate();
		// Important AF
        con.commit();
        ps.close();
    	}
    	catch(Exception e){
    		state = 1;
    	}
    	
    	// code d'erreur
    	if (affectedRows > 0) {
    		state = 0;
            
    	}
    	//System.out.println("RejoindreLot State : " + state);
        return state;
	}
	
	// R05
	public int supprimerLot(String nomLot) throws SQLException {
    	int state = 1;
    	PreparedStatement ps = con.prepareStatement("DELETE FROM LotMembre WHERE nomLot = ?");
    	int affectedRows = 0;
    	
    	try {
    	    ps.setString(1, nomLot);
    	    affectedRows = ps.executeUpdate();
            con.commit();
            ps.close();
    	    state = 0;
    	} catch(Exception e) {
    	    System.out.println("I was already deleted. Let me introduce myself...");    	    
    	}
    	if (affectedRows != 1) {
    	    state = 1;
    	}
    	//System.out.println("SypprimerLot State : " + state);
    	return state;
    }
	
	public int supprimerTuple(String nomLot, String noMembre) throws SQLException {
    	int state = 1;
    	PreparedStatement ps = con.prepareStatement("DELETE FROM LotMembre WHERE nomLot = ? AND noMembre = ?");
    	int affectedRows = 0;
    	
    	try {
    	    ps.setString(1, nomLot);
    	    ps.setString(2, noMembre);
    	    
    	    affectedRows = ps.executeUpdate();
            con.commit();
            ps.close();
    	    state = 0;
    	} catch(Exception e) {
    	    System.out.println("I was already deleted. Let me introduce myself...");    	    
    	}
    	if (affectedRows > 1) {
    	    state = 1;
    	}
    	//System.out.println("SypprimerLotMembre state : " + state);
    	return state;
    }
	
	public void showTable() throws SQLException
    {
        Statement s = con.createStatement();
        String query = "SELECT * FROM LotMembre";
        ResultSet rSet = s.executeQuery(query);
        System.out.println("LotMembre :\n | nomLot | nbMaxMembre |\n"
        				  +"======================================");
        while (rSet.next()) {
            String nomLot = rSet.getString("nomLot");
            String noMembre = rSet.getString("noMembre");
            
            System.out.println("| "+nomLot+" | "+noMembre+" |");
        }
        System.out.println("");
    }
}
