package TP2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Plantes extends Table {

	public Plantes(Connection beepboop) throws SQLException {
		super(beepboop);
	}
	
	public void showTable() throws SQLException
    {
        Statement s = con.createStatement();
        String query = "SELECT * FROM Plante";
        ResultSet rSet = s.executeQuery(query);
        System.out.println("\nPlante :\n| nomPlante | tempsCulture | estDisponible |\n"
        				  +"===================================================");
        while (rSet.next()) {
            String nomPlante = rSet.getString("nomPlante");
            String tempsCulture = rSet.getString("tempsCulture");
            boolean estDisponible = rSet.getBoolean("estDisponible");
            
            System.out.println("| "+nomPlante+" | "+tempsCulture+" | "+estDisponible+" |");
        }
        System.out.println("");
        
    }
	
	// R09
	public int ajouterPlante(String nomPlante, int tempsCulture) throws SQLException {
		int state = 1;
    	int affectedRows = 0;
    	
    	
    	supprimerPlante(nomPlante);
    	
    	PreparedStatement ps = con.prepareStatement("INSERT INTO Plante(nomPlante, tempsCulture) VALUES (?,?)");
    	ps.setString(1, nomPlante);
    	ps.setInt(2, tempsCulture);
    	
    	//this.supprimerPlante(nomPlante);
    	try {
    	affectedRows = ps.executeUpdate();
		// Important AF
        con.commit();
        ps.close();
    	}
    	catch(Exception e){
    		state = 1;
    	}
    	
    	// code d'erreur
    	if (affectedRows > 0) {
    		state = 0;
            
    	}
    	
    	//System.out.println("AjouterPlante State : " + state);
        return state;
	}
	
	
	public int supprimerPlante(String nomPlante) throws SQLException {
		int state = 1;
    	PreparedStatement ps = con.prepareStatement("DELETE FROM Plante WHERE nomPlante = ?");
    	int affectedRows = 0;
    	
    	try {
    	    ps.setString(1, nomPlante);
    	    affectedRows = ps.executeUpdate();
            con.commit();
            ps.close();
    	    state = 0;
    	} catch(Exception e) {}
    	if (affectedRows > 1) {
    	    state = 1;
    	}
    	//System.out.println("SypprimerPlante State :" + state);
    	return state;
	}
	
	// R10
	public int retirerPlante(String nomPlante) throws SQLException {
		int state = 1;
    	PreparedStatement ps = con.prepareStatement("UPDATE Plante SET estDisponible = FALSE WHERE nomPlante = ?");
    	int affectedRows = 0;
    	
    	try {
    	    ps.setString(1, nomPlante);
    	    affectedRows = ps.executeUpdate();
            con.commit();
            ps.close();
    	    state = 0;
    	} catch(Exception e) {}
    	if (affectedRows > 1) {
    	    state = 1;
    	}
    	//System.out.println("RetirerPlante State : " + state);
    	return state;
	}
	
}
