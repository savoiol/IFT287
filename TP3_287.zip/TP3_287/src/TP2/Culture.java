package TP2;

import java.util.Date;

import javax.persistence.*;


public class Culture
{
    @Id
    @GeneratedValue
    private long m_id;
    
    private String m_nomPlante;
    private String m_nomLot;
    private String m_noMembre;
    private int m_nbExemplaires;
    private Date m_datePlantation;
    private Date m_dateRecolte;
    
    
    public Culture() {    
    }
    
    public Culture(String nomPlante, String nomLot, String noMembre, int nbExemplaires, Date datePlantation, Date dateRecolte) {    
        m_nomPlante = nomPlante;
        m_nomLot = nomLot;
        m_noMembre = noMembre;
        m_nbExemplaires = nbExemplaires;
        m_datePlantation = datePlantation;
        m_dateRecolte = dateRecolte;
    }
    
    public String getNoPlantem() {
        return m_nomPlante;
    }
    
    public String getNomLot() {
        return m_nomLot;
    }

    public String getNoMembre() {
        return m_noMembre;
    }

    public int getNbExemplaires() {
        return m_nbExemplaires;
    }
    
    public Date getDatePlantation() {
        return m_datePlantation;
    }
    
    public Date getDateRecolte() {
        return m_dateRecolte;
    }
}
