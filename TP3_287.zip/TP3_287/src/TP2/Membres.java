package TP2;

import java.sql.*;
import java.sql.SQLException;

public class Membres extends Table
{

    //private Connexion con;
    
    public Membres(Connection beepboop) throws SQLException
    {
        super(beepboop);
        //con = beepboop;
    }

    public void showTable() throws SQLException
    {
        Statement s = con.createStatement();
        String query = "SELECT * FROM MEMBRE";
        ResultSet rSet = s.executeQuery(query);
        System.out.println("MEMBRE :\n | nomember | nom | prenom | motdepasse | admin |\n"
        				  +"===========================================================");
        while (rSet.next()) {
            String nomembre = rSet.getString("nomembre");
            String nom = rSet.getString("nom");
            String prenom = rSet.getString("prenom");
            String mdp = rSet.getString("motdepasse");
            boolean admin = rSet.getBoolean("admin");
            
            System.out.println("| "+nomembre+" | "+nom+" | "+prenom+" | "+mdp+" | "+admin+" |");
        }
        System.out.println("");
    }

    // R01
    public int inscrireMembre(String nom, String prenom, String motdepasse, String nomembre) throws SQLException
    {
    	int state = 1;
    	int affectedRows = 0;
    	
    	PreparedStatement ps = con.prepareStatement("INSERT INTO Membre(nom, prenom, noMembre, motDePasse) VALUES\r\n" + 
    			"  (?,?,?,?)");
    	ps.setString(1, nom);
    	ps.setString(2, prenom);
    	ps.setString(3, nomembre);
    	ps.setString(4, motdepasse);
    	this.supprimerMembre(nomembre);
    	try {
    	affectedRows = ps.executeUpdate();
		
        con.commit();
        ps.close();
        
    	} catch(Exception e) {
    		state = 1;
    	}
    	// code d'erreur
    	if (affectedRows > 0) {
    		state = 0;

    	}
    	//System.out.println("InscrirMembre State : " + state);
        return state;
    }
    
    //R02  
    public int supprimerMembre(String nomembre) throws SQLException {
    	int state = 1;
    	PreparedStatement ps = con.prepareStatement("DELETE FROM Membre WHERE nomembre = ?");
    	int affectedRows = 0;
    	
    	try {
    	    ps.setString(1, nomembre);
    	    affectedRows = ps.executeUpdate();
            con.commit();
            ps.close();
    	    state = 0;
    	} catch(Exception e) {
    	    System.out.println("I was already deleted. Let me introduce myself...");    	    
    	}
    	if (affectedRows > 1) {
    	    state = 1;
    	}
    	//System.out.println("SypprimerMembre State :" + state);
    	return state;
    }
    
    //R03
    public int promouvoirAdministrateur(String nomembre) throws SQLException {
    	int state = 1;
    	
    	PreparedStatement ps = con.prepareStatement("UPDATE Membre SET admin = '1' WHERE nomembre = ?");
    	int affectedRows = 0;
    	
    	try {
    	    ps.setString(1, nomembre);
    	    affectedRows = ps.executeUpdate();
            con.commit();
            ps.close();
    	    state = 0;
    	} catch(Exception e) {}
    	
    	if (affectedRows != 1) {
    	    state = 1;
    	}
    	//System.out.println("PromouvoirAdministrateur State : " + state);
    	
    	return state;
    }
    	
}
