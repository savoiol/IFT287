package TP2;

import javax.persistence.*;

public class DemandeMembreLot
{
    @Id
    @GeneratedValue
    private long m_id;

    private String m_nomLot;
    private String m_noMembre;

    public DemandeMembreLot()
    {
    }

    public DemandeMembreLot(String nomLot, String noMembre)
    {
        m_nomLot = nomLot;
        m_noMembre = noMembre;
    }

    public String getNomLot()
    {
        return m_nomLot;
    }

    public String getNoMembre()
    {
        return m_noMembre;
    }

}
