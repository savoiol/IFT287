 -- Permet de supprimer les tables (et le contenues des tables en même temps)
DROP TABLE Culture;
DROP TABLE LotMembre;
DROP TABLE DemandeMembreLot;
DROP TABLE Membre;
DROP TABLE Lot;
DROP TABLE Plante;